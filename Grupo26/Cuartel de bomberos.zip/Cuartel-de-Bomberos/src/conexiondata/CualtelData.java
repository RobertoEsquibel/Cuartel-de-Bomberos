
package conexiondata;


public class CualtelData {
    
}
